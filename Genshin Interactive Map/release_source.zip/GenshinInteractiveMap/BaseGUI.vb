﻿
Imports System.IO

' ne rêver pas je n'expliquerais rien, remercier micorosft qui ont niquer ce projet 

Public Class BaseGUI
    Public current_version As String = "1.0"
    Private Sub BaseGUI_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        WebView21.Source = New Uri("https://act.hoyolab.com/ys/app/interactive-map/index.html")
        ' UpdateChecker.CheckUpdate() ' je retire ca, vraiment flemme de faire des mis a jours à distance, les mis a jours seront sur github (merci microsoft)
    End Sub

    Private Sub ReloadToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ReloadToolStripMenuItem.Click
        WebView21.Reload()
    End Sub

    Private Sub WebView21_KeyDown(sender As Object, e As KeyEventArgs) Handles WebView21.KeyDown
        e.Handled = True
    End Sub

    Private Sub ScreenshotMapToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ScreenshotMapToolStripMenuItem.Click
        ScreenshotViewer.Hide()
        ScreenshotViewer.img_bitmap = New Bitmap(WebView21.Width, WebView21.Height)
        Using g As Graphics = Graphics.FromImage(ScreenshotViewer.img_bitmap)
            g.CompositingQuality = Drawing2D.CompositingQuality.GammaCorrected
            g.CopyFromScreen(WebView21.PointToScreen(New Point(0, 0)), New Point(0, 0), New Size(WebView21.Width, WebView21.Height))
        End Using
        ScreenshotViewer.img_bitmap = ScreenshotViewer.img_bitmap
        ScreenshotViewer.PictureBox1.Image = ScreenshotViewer.img_bitmap
        ScreenshotViewer.Show()
    End Sub
End Class
