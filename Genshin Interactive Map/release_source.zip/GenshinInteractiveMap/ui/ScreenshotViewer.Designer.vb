﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ScreenshotViewer
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ScreenshotViewer))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.right_menu_screen_view = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.SaveToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveAsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.JpegToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IconToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PngToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BmpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EmfToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExifToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TiffToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WmfToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenAfterSavedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.right_menu_screen_view.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.ContextMenuStrip = Me.right_menu_screen_view
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(741, 417)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'right_menu_screen_view
        '
        Me.right_menu_screen_view.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CopyToolStripMenuItem, Me.ToolStripSeparator2, Me.SaveToolStripMenuItem1, Me.SaveAsToolStripMenuItem, Me.ToolStripSeparator1, Me.SaveToolStripMenuItem, Me.ActionToolStripMenuItem})
        Me.right_menu_screen_view.Name = "right_menu_screen_view"
        Me.right_menu_screen_view.Size = New System.Drawing.Size(181, 148)
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.CopyToolStripMenuItem.Text = "Copy"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(177, 6)
        '
        'SaveToolStripMenuItem1
        '
        Me.SaveToolStripMenuItem1.Name = "SaveToolStripMenuItem1"
        Me.SaveToolStripMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.SaveToolStripMenuItem1.Text = "Save"
        '
        'SaveAsToolStripMenuItem
        '
        Me.SaveAsToolStripMenuItem.Name = "SaveAsToolStripMenuItem"
        Me.SaveAsToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.SaveAsToolStripMenuItem.Text = "Save As..."
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(177, 6)
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.JpegToolStripMenuItem, Me.IconToolStripMenuItem, Me.PngToolStripMenuItem, Me.BmpToolStripMenuItem, Me.EmfToolStripMenuItem, Me.ExifToolStripMenuItem, Me.WmfToolStripMenuItem, Me.TiffToolStripMenuItem})
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.SaveToolStripMenuItem.Text = "Format"
        '
        'JpegToolStripMenuItem
        '
        Me.JpegToolStripMenuItem.Checked = True
        Me.JpegToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.JpegToolStripMenuItem.Name = "JpegToolStripMenuItem"
        Me.JpegToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.JpegToolStripMenuItem.Text = "jpeg"
        '
        'IconToolStripMenuItem
        '
        Me.IconToolStripMenuItem.Name = "IconToolStripMenuItem"
        Me.IconToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.IconToolStripMenuItem.Text = "icon"
        '
        'PngToolStripMenuItem
        '
        Me.PngToolStripMenuItem.Name = "PngToolStripMenuItem"
        Me.PngToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.PngToolStripMenuItem.Text = "png"
        '
        'BmpToolStripMenuItem
        '
        Me.BmpToolStripMenuItem.Name = "BmpToolStripMenuItem"
        Me.BmpToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.BmpToolStripMenuItem.Text = "bmp"
        '
        'EmfToolStripMenuItem
        '
        Me.EmfToolStripMenuItem.Name = "EmfToolStripMenuItem"
        Me.EmfToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.EmfToolStripMenuItem.Text = "emf"
        '
        'ExifToolStripMenuItem
        '
        Me.ExifToolStripMenuItem.Name = "ExifToolStripMenuItem"
        Me.ExifToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ExifToolStripMenuItem.Text = "exif"
        '
        'TiffToolStripMenuItem
        '
        Me.TiffToolStripMenuItem.Name = "TiffToolStripMenuItem"
        Me.TiffToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.TiffToolStripMenuItem.Text = "tiff"
        '
        'WmfToolStripMenuItem
        '
        Me.WmfToolStripMenuItem.Name = "WmfToolStripMenuItem"
        Me.WmfToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.WmfToolStripMenuItem.Text = "wmf"
        '
        'ActionToolStripMenuItem
        '
        Me.ActionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenAfterSavedToolStripMenuItem})
        Me.ActionToolStripMenuItem.Name = "ActionToolStripMenuItem"
        Me.ActionToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ActionToolStripMenuItem.Text = "Action"
        '
        'OpenAfterSavedToolStripMenuItem
        '
        Me.OpenAfterSavedToolStripMenuItem.Name = "OpenAfterSavedToolStripMenuItem"
        Me.OpenAfterSavedToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.OpenAfterSavedToolStripMenuItem.Text = "Open After Saved"
        '
        'ScreenshotViewer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(741, 417)
        Me.Controls.Add(Me.PictureBox1)
        Me.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "ScreenshotViewer"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Screenshot Viewer"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.right_menu_screen_view.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents right_menu_screen_view As ContextMenuStrip
    Friend WithEvents SaveToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents SaveToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents SaveAsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents JpegToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents IconToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PngToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BmpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents EmfToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents ExifToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WmfToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TiffToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ActionToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpenAfterSavedToolStripMenuItem As ToolStripMenuItem
End Class
