﻿Public Class ScreenshotViewer
    Public img_bitmap As Bitmap
    Private Sub ScreenshotTool_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        OpenAfterSavedToolStripMenuItem.CheckOnClick = True
    End Sub

    Private Sub SaveToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles SaveToolStripMenuItem1.Click
        Dim name_file As String = "", format_file As Imaging.ImageFormat, correct_hours As String = ""
        If Date.Now.Hour <= 9 Then
            correct_hours = "0" & CStr(Date.Now.Hour) & "-"
        Else
            correct_hours = CStr(Date.Now.Hour) & "-"
        End If
        If Date.Now.Minute <= 9 Then
            correct_hours += "0" & CStr(Date.Now.Minute) & "-"
        Else
            correct_hours += CStr(Date.Now.Minute) & "-"
        End If
        If Date.Now.Second <= 9 Then
            correct_hours += "0" & CStr(Date.Now.Second)
        Else
            correct_hours += CStr(Date.Now.Second)
        End If
        If JpegToolStripMenuItem.Checked Then
            name_file = My.Computer.FileSystem.SpecialDirectories.Desktop() & "\genshin_map_screen[" & correct_hours & "].jpeg"
            format_file = Imaging.ImageFormat.Jpeg
        ElseIf IconToolStripMenuItem.Checked Then
            name_file = My.Computer.FileSystem.SpecialDirectories.Desktop() & "\genshin_map_screen[" & correct_hours & "].ico"
            format_file = Imaging.ImageFormat.Icon
        ElseIf PngToolStripMenuItem.Checked Then
            name_file = My.Computer.FileSystem.SpecialDirectories.Desktop() & "\genshin_map_screen[" & correct_hours & "].png"
            format_file = Imaging.ImageFormat.Png
        ElseIf BmpToolStripMenuItem.Checked Then
            name_file = My.Computer.FileSystem.SpecialDirectories.Desktop() & "\genshin_map_screen[" & correct_hours & "].bmp"
            format_file = Imaging.ImageFormat.Bmp
        ElseIf EmfToolStripMenuItem.Checked Then
            name_file = My.Computer.FileSystem.SpecialDirectories.Desktop() & "\genshin_map_screen[" & correct_hours & "].emf"
            format_file = Imaging.ImageFormat.Emf
        ElseIf ExifToolStripMenuItem.Checked Then
            name_file = My.Computer.FileSystem.SpecialDirectories.Desktop() & "\genshin_map_screen[" & correct_hours & "].exif"
            format_file = Imaging.ImageFormat.Exif
        ElseIf WmfToolStripMenuItem.Checked Then
            name_file = My.Computer.FileSystem.SpecialDirectories.Desktop() & "\genshin_map_screen[" & correct_hours & "].wmf"
            format_file = Imaging.ImageFormat.Wmf
        ElseIf TiffToolStripMenuItem.Checked Then
            name_file = My.Computer.FileSystem.SpecialDirectories.Desktop() & "\genshin_map_screen[" & correct_hours & "].tiff"
            format_file = Imaging.ImageFormat.Tiff
        End If
        Try
            img_bitmap.Save(name_file, format_file)
            If OpenAfterSavedToolStripMenuItem.Checked Then
                Process.Start(name_file)
            End If
        Catch : End Try
    End Sub

    Private Sub CopyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyToolStripMenuItem.Click
        Try
            My.Computer.Clipboard.SetImage(img_bitmap)
        Catch : End Try
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveAsToolStripMenuItem.Click
        Dim saveDIalog As New SaveFileDialog
        saveDIalog.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.Desktop()
        saveDIalog.Filter = "Image File |*.jpeg;*.ico;*.png;*.bmp;*.emf;*.exif;*.wmf;*.tiff"
        If saveDIalog.ShowDialog() = DialogResult.OK Then
            Try
                img_bitmap.Save(saveDIalog.FileName)
                If OpenAfterSavedToolStripMenuItem.Checked Then
                    Process.Start(saveDIalog.FileName)
                End If
            Catch : End Try
        End If
    End Sub

    Private Sub JpegToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles JpegToolStripMenuItem.Click
        JpegToolStripMenuItem.Checked = True
        IconToolStripMenuItem.Checked = False
        PngToolStripMenuItem.Checked = False
        BmpToolStripMenuItem.Checked = False
        EmfToolStripMenuItem.Checked = False
        ExifToolStripMenuItem.Checked = False
        WmfToolStripMenuItem.Checked = False
        TiffToolStripMenuItem.Checked = False
    End Sub

    Private Sub IconToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles IconToolStripMenuItem.Click
        JpegToolStripMenuItem.Checked = False
        IconToolStripMenuItem.Checked = True
        PngToolStripMenuItem.Checked = False
        BmpToolStripMenuItem.Checked = False
        EmfToolStripMenuItem.Checked = False
        ExifToolStripMenuItem.Checked = False
        WmfToolStripMenuItem.Checked = False
        TiffToolStripMenuItem.Checked = False
    End Sub

    Private Sub PngToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PngToolStripMenuItem.Click
        JpegToolStripMenuItem.Checked = False
        IconToolStripMenuItem.Checked = False
        PngToolStripMenuItem.Checked = True
        BmpToolStripMenuItem.Checked = False
        EmfToolStripMenuItem.Checked = False
        ExifToolStripMenuItem.Checked = False
        WmfToolStripMenuItem.Checked = False
        TiffToolStripMenuItem.Checked = False
    End Sub

    Private Sub BmpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BmpToolStripMenuItem.Click
        JpegToolStripMenuItem.Checked = False
        IconToolStripMenuItem.Checked = False
        PngToolStripMenuItem.Checked = False
        BmpToolStripMenuItem.Checked = True
        EmfToolStripMenuItem.Checked = False
        ExifToolStripMenuItem.Checked = False
        WmfToolStripMenuItem.Checked = False
        TiffToolStripMenuItem.Checked = False
    End Sub

    Private Sub EmfToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EmfToolStripMenuItem.Click
        JpegToolStripMenuItem.Checked = False
        IconToolStripMenuItem.Checked = False
        PngToolStripMenuItem.Checked = False
        BmpToolStripMenuItem.Checked = False
        EmfToolStripMenuItem.Checked = True
        ExifToolStripMenuItem.Checked = False
        WmfToolStripMenuItem.Checked = False
        TiffToolStripMenuItem.Checked = False
    End Sub

    Private Sub ExifToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExifToolStripMenuItem.Click
        JpegToolStripMenuItem.Checked = False
        IconToolStripMenuItem.Checked = False
        PngToolStripMenuItem.Checked = False
        BmpToolStripMenuItem.Checked = False
        EmfToolStripMenuItem.Checked = False
        ExifToolStripMenuItem.Checked = True
        WmfToolStripMenuItem.Checked = False
        TiffToolStripMenuItem.Checked = False
    End Sub

    Private Sub WmfToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WmfToolStripMenuItem.Click
        JpegToolStripMenuItem.Checked = False
        IconToolStripMenuItem.Checked = False
        PngToolStripMenuItem.Checked = False
        BmpToolStripMenuItem.Checked = False
        EmfToolStripMenuItem.Checked = False
        ExifToolStripMenuItem.Checked = False
        WmfToolStripMenuItem.Checked = True
        TiffToolStripMenuItem.Checked = False
    End Sub

    Private Sub TiffToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TiffToolStripMenuItem.Click
        JpegToolStripMenuItem.Checked = False
        IconToolStripMenuItem.Checked = False
        PngToolStripMenuItem.Checked = False
        BmpToolStripMenuItem.Checked = False
        EmfToolStripMenuItem.Checked = False
        ExifToolStripMenuItem.Checked = False
        WmfToolStripMenuItem.Checked = False
        TiffToolStripMenuItem.Checked = True
    End Sub

End Class