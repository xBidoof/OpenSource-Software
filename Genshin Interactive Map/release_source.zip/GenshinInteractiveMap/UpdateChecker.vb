﻿
Imports System.Net

Public Class UpdateChecker
    Shared wc As New WebClient
    Shared Sub CheckUpdate()
        AddHandler wc.DownloadStringCompleted, AddressOf UpdateCheckerHandle
        wc.DownloadStringAsync(New Uri("https://pastebin.com/raw/KNsgDYVN"))
    End Sub
    Private Shared Sub UpdateCheckerHandle(sender As Object, e As DownloadStringCompletedEventArgs)
        Dim split_line As String() = Split(e.Result, Environment.NewLine)
        If BaseGUI.current_version <> split_line(0) Then
            If MessageBox.Show("a new update is available" & vbNewLine & vbNewLine & BaseGUI.current_version & " -> " & split_line(0) & vbNewLine & vbNewLine & "do you want to download it ?", "Genshin Interactive Map", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                DownloadUpdate(split_line(1))
            End If
        End If
    End Sub

    Private Shared Sub DownloadUpdate(url As String)
        RemoveHandler wc.DownloadStringCompleted, AddressOf UpdateCheckerHandle
        AddHandler wc.DownloadProgressChanged, AddressOf DownloadFileHandle
        wc.DownloadFileAsync(New Uri(url), Application.StartupPath & "\tmp\last_version.zip")
        UpdateUI.Show()
    End Sub

    Private Shared Sub DownloadFileHandle(ByVal sender As Object, ByVal e As DownloadProgressChangedEventArgs)
        UpdateUI.Label3.Text = e.ProgressPercentage.ToString() + " %"
        UpdateUI.Label2.Text = String.Format("{0} MB's / {1} MB's", (e.BytesReceived / 1028D / 1028D).ToString("0.00"), (e.TotalBytesToReceive / 1028D / 1028D).ToString("0.00"))
        If UpdateUI.Label3.Text.Contains("100 %") Then
            Threading.Thread.Sleep(200)
            Try
                Process.Start(Application.StartupPath & "\_unzipper.exe", "-zip_decompress 'tmp\last_version.zip' -process_name 'GenshinInteractiveMap' -process_start 'GenshinInteractiveMap.exe' -soft_name 'Genshin Interactive Tool'")
                BaseGUI.Close()
            Catch ex As Exception
                MessageBox.Show("Failed to start extraction update" & vbNewLine & vbNewLine & "Message: " & ex.Message, "Genshin Interactive Map", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
End Class
